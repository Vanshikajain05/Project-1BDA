package MapR;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;


public class P1Q3 {
	public static class MapForMaxCount extends Mapper<LongWritable, Text, Text, IntWritable>
	{
		public void map(LongWritable key, Text value, Context con) throws IOException, InterruptedException{
			
			if(key.get()==0){
				return;
			}
			else{
			String line =value.toString();
			String[] st= line.split(",");
			
				Text t=new Text (st[3]);
				IntWritable i= new IntWritable(1);
				con.write(t, i);
			
		}
		}
	}
	
	public static class ReduceForMaxCount extends Reducer<Text, IntWritable, Text, IntWritable>{
		Map <Text, IntWritable> map=new HashMap<Text, IntWritable>();
		
		public void reduce (Text lines, Iterable<IntWritable> values, Context con)throws IOException, InterruptedException{
			int sum=0;
			
			for(IntWritable value:values){
				sum=sum+value.get();
			}
			map.put(lines, new IntWritable(sum));
			 
			//getMax(map);
			//key=getMax(map).getKey();
			//v=getMax(map).getValue();
			//con.write(key, v);
		}
		
		
	public void cleanup(Context con) throws IOException, InterruptedException
    { 
        Map.Entry<Text, IntWritable> entry = null; 
        for (Map.Entry<Text, IntWritable> current:map.entrySet()) { 
  
           if (entry == null|| current.getValue().compareTo(entry.getValue())> 0) { 
                entry = current; 
            } 
        } 
       // return entry; 
        con.write(entry.getKey(), entry.getValue());
    } 
	}
	
	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException{
		Configuration conf= new Configuration();
		Job j=Job.getInstance(conf,"maxcount");
		j.setJarByClass(P1Q3.class);
		j.setMapperClass(MapForMaxCount.class);
		j.setReducerClass(ReduceForMaxCount.class);
		j.setOutputKeyClass(Text.class);
		j.setOutputValueClass(IntWritable.class);
		FileInputFormat.addInputPath(j, new Path(args[0]));
		FileOutputFormat.setOutputPath(j, new Path(args[1]));
		System.exit(j.waitForCompletion(true)?0:1);
	}
}
